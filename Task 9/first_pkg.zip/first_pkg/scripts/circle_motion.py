#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import String

# This function is called whenever a new message is received on the /status topic
def status_callback(msg):
    rospy.loginfo("Received status: %s", msg.data)

def move_in_circle():
    # Initialize the ROS node
    rospy.init_node('circle_mover', anonymous=True)

    # Publisher to control turtle movement
    velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)

    # Publisher to publish the rotating status
    status_publisher = rospy.Publisher('/status', String, queue_size=10)

    # Internal subscriber that listens to the /status topic
    rospy.Subscriber('/status', String, status_callback)

    # Set loop rate to 1 Hz
    rate = rospy.Rate(1)

    # Twist message for circular motion
    vel_msg = Twist()
    vel_msg.linear.x = 2.0      # forward speed
    vel_msg.angular.z = 1.0     # rotation speed

    while not rospy.is_shutdown():
        velocity_publisher.publish(vel_msg)             # move the turtle
        status_publisher.publish("rotating")            # publish status
        rate.sleep()

if __name__ == '__main__':
    try:
        move_in_circle()
    except rospy.ROSInterruptException:
        pass
