#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

# Callback function that gets called when a message is received
def callback(data):
    rospy.loginfo("Received message: %s", data.data)
    rospy.loginfo("Type of message: %s", type(data.data))

# Initialize the node with the name 'listener'
rospy.init_node('listener')

# Subscribe to the 'chatter' topic and attach the callback
rospy.Subscriber('chatter', String, callback)

# Keep the node running
rospy.spin()
