#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import time

def status_callback(msg):
    rospy.loginfo("Status received: %s", msg.data)

def move_in_square():
    rospy.init_node('square_mover', anonymous=True)

    velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    status_publisher = rospy.Publisher('/status', String, queue_size=10)

    rospy.Subscriber('/status', String, status_callback)

    vel_msg = Twist()
    rate = rospy.Rate(1)

    for _ in range(4):
        # Move forward
        vel_msg.linear.x = 2.0
        vel_msg.angular.z = 0.0
        status_publisher.publish("forward")
        rospy.loginfo("Moving forward...")
        velocity_publisher.publish(vel_msg)
        time.sleep(2)

        # Rotate 90 degrees
        vel_msg.linear.x = 0.0
        vel_msg.angular.z = 1.57
        status_publisher.publish("rotating")
        rospy.loginfo("Rotating...")
        velocity_publisher.publish(vel_msg)
        time.sleep(1.1)

    # Stop the turtle
    vel_msg.linear.x = 0.0
    vel_msg.angular.z = 0.0
    velocity_publisher.publish(vel_msg)
    rospy.loginfo("Square path complete. Turtle stopped.")

if __name__ == '__main__':
    try:
        move_in_square()
    except rospy.ROSInterruptException:
        pass
