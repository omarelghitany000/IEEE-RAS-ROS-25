#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

# Initialize the node with the name 'talker'
rospy.init_node('talker')

# Create a publisher to the 'chatter' topic, with message type String
pub = rospy.Publisher('chatter', String, queue_size=10)

# Set the loop rate to 1Hz (one message per second)
rate = rospy.Rate(1)

# Keep publishing messages until the node is shut down
while not rospy.is_shutdown():
    msg = "Hello from talker"
    rospy.loginfo(msg)
    pub.publish(msg)
    rate.sleep()
