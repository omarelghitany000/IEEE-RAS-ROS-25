#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist

def move_forward():
    rospy.init_node("move_forward_node", anonymous=True)
    pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    vel_msg = Twist()
    vel_msg.linear.x = 0.1  
    vel_msg.angular.z = 0.0

    rate = rospy.Rate(10)
    t0 = rospy.Time.now().to_sec()

    while not rospy.is_shutdown():
        t1 = rospy.Time.now().to_sec()
        if t1 - t0 > 3.5:   
            break
        pub.publish(vel_msg)
        rate.sleep()

    
    vel_msg.linear.x = 0.0
    pub.publish(vel_msg)

if __name__ == "__main__":
    try:
        move_forward()
    except rospy.ROSInterruptException:
        pass
