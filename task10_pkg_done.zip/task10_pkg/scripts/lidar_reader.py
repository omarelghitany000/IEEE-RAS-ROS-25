#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32

def callback(scan):
    valid_ranges = [r for r in scan.ranges if r > 0.0 and r < float('inf')]

    if valid_ranges:
        closest_distance = min(valid_ranges)
        rospy.loginfo("Closest object distance: %.2f m", closest_distance)

        pub.publish(closest_distance)
    else:
        rospy.logwarn("No valid LIDAR readings detected!")

if __name__ == '__main__':
    rospy.init_node('lidar_reader', anonymous=True)

    pub = rospy.Publisher('/closest_distance', Float32, queue_size=10)

    rospy.Subscriber('/scan', LaserScan, callback)

    rospy.loginfo("Lidar Reader Node Started...")

    rospy.spin()
