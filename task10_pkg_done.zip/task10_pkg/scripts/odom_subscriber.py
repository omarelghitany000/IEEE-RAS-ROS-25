#!/usr/bin/env python3
import rospy
from nav_msgs.msg import Odometry
from math import sqrt

class OdomReader:
    def __init__(self):
        self.start_x = None
        self.start_y = None
        rospy.Subscriber("/odom", Odometry, self.odom_callback)

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        if self.start_x is None:
            self.start_x = x
            self.start_y = y
            rospy.loginfo("Starting position saved")
        else:
            distance = sqrt((x - self.start_x)**2 + (y - self.start_y)**2)
            rospy.loginfo(f"Current position: ({x:.2f}, {y:.2f}) | Distance: {distance:.3f} m")

if __name__ == "__main__":
    rospy.init_node("odom_reader_node", anonymous=True)
    OdomReader()
    rospy.spin()
