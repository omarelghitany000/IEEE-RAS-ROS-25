#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

def callback1(msg):
    rospy.loginfo("From pub1: %s", msg.data)

def callback2(msg):
    rospy.loginfo("From pub2: %s", msg.data)

def listener():
    rospy.init_node('subscriber', anonymous=True)
    rospy.Subscriber('chatter1', String, callback1)
    rospy.Subscriber('chatter2', String, callback2)
    rospy.spin()

if __name__ == '__main__':
    listener()
