#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math

class MoveOdom:
    def __init__(self):
        rospy.init_node("odom_autonomous")
        self.pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)
        self.start_x = None
        self.start_y = None
        self.dist_target = 0.3
        self.speed = 0.1
        self.current_x = 0.0
        self.current_y = 0.0
        rospy.loginfo("Starting move...")
        self.run()

    def odom_callback(self, msg):
        pos = msg.pose.pose.position
        if self.start_x is None:
            self.start_x, self.start_y = pos.x, pos.y
        self.current_x, self.current_y = pos.x, pos.y

    def distance_moved(self):
        dx = self.current_x - self.start_x
        dy = self.current_y - self.start_y
        return math.sqrt(dx*dx + dy*dy)

    def run(self):
        rate = rospy.Rate(10)
        move = Twist()
        move.linear.x = self.speed
        while not rospy.is_shutdown():
            if self.start_x is not None:
                if self.distance_moved() >= self.dist_target:
                    move.linear.x = 0
                    self.pub.publish(move)
                    rospy.loginfo("Reached 30cm, stopping.")
                    break
            self.pub.publish(move)
            rate.sleep()

if __name__ == "__main__":
    MoveOdom()
