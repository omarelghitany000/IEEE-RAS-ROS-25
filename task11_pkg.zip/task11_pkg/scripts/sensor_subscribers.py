#!/usr/bin/env python3
import rospy
import numpy as np
from sensor_msgs.msg import LaserScan, Imu
from nav_msgs.msg import Odometry
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point, Quaternion
from std_msgs.msg import Header

def scan_callback(msg):
    # compute closest valid range
    ranges = np.array(msg.ranges)
    # mask invalids (inf, nan, <range_min)
    valid = np.isfinite(ranges) & (ranges > msg.range_min)
    if not np.any(valid):
        rospy.loginfo("No valid scan values")
        return
    idx = np.where(valid)[0][np.argmin(ranges[valid])]
    # careful: idx from original array
    all_valid_indices = np.where(valid)[0]
    idx_global = all_valid_indices[np.argmin(ranges[valid])]
    r = ranges[idx_global]
    angle = msg.angle_min + idx_global * msg.angle_increment
    x = r * np.cos(angle)
    y = r * np.sin(angle)
    rospy.loginfo("Closest object distance: %.3f m (angle %.3f rad)" % (r, angle))

    # publish a visualization marker in base_link frame
    marker = Marker()
    marker.header = Header()
    marker.header.stamp = rospy.Time.now()
    marker.header.frame_id = "base_link"
    marker.ns = "ultra_marker"
    marker.id = 0
    marker.type = Marker.SPHERE
    marker.action = Marker.ADD
    marker.pose.position = Point(x, y, 0.0)
    # no rotation needed
    marker.scale.x = 0.12
    marker.scale.y = 0.12
    marker.scale.z = 0.12
    marker.color.r = 1.0
    marker.color.g = 0.0
    marker.color.b = 0.0
    marker.color.a = 0.9
    marker.lifetime = rospy.Duration(1.0)
    marker_pub.publish(marker)

def odom_callback(msg):
    # republish orientation as a fake IMU (orientation only)
    imu_msg = Imu()
    imu_msg.header = Header()
    imu_msg.header.stamp = rospy.Time.now()
    imu_msg.header.frame_id = "base_link"
    imu_msg.orientation = msg.pose.pose.orientation
    # leave covariances zero (not filled)
    imu_pub.publish(imu_msg)
    # optionally log orientation (yaw)
    q = msg.pose.pose.orientation
    # convert quaternion to yaw
    import tf
    euler = tf.transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])
    yaw = euler[2]
    rospy.loginfo("Odom (yaw): %.3f rad" % yaw)

def listener():
    rospy.init_node('sensor_subscribers', anonymous=True)
    rospy.Subscriber('/scan', LaserScan, scan_callback)
    rospy.Subscriber('/odom', Odometry, odom_callback)
    rospy.loginfo("sensor_subscribers node started: listening to /scan and /odom, publishing /imu and /visualization_marker")
    rospy.spin()

if __name__ == '__main__':
    imu_pub = rospy.Publisher('/imu', Imu, queue_size=10)
    marker_pub = rospy.Publisher('/visualization_marker', Marker, queue_size=10)
    listener()
